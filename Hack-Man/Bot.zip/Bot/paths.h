#ifndef PATHS_H
#define PATHS_H
extern const int index[20][14];
extern const int paths[162][162];
extern const int path_lengths[162][162];
extern const int paths_with_direction[4][162][162];
extern const int path_lengths_with_direction[4][162][162];
#endif
